
var str = "Hello, playground"
var age = 22
age = 24

